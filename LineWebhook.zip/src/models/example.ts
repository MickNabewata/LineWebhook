/** モデル実装例 GET INPUT */
export interface ExampleGetInput
{
    /** プロパティ1 */
    param1? : string;
}

/** モデル実装例 GET OUTPUT */
export interface ExampleGetOutput
{
    /** プロパティ1 */
    param1? : string;
}